import pygame
import sys

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (81, 66, 252)
RED = (237, 76, 76)
LIGHT_RED = (255, 130, 130)
GREEN = (130, 255, 172)

WIDTH = 700
HEIGHT = 700

screen = pygame.display.set_mode((WIDTH, HEIGHT))

# Add a global constant for promotion pieces
PROMOTION_PIECES = ["Queen", "Rook", "Bishop", "Knight"]

class ChessGame:
    def __init__(self):
        self.board = [
            ["bR", "bN", "bB", "bQ", "bK", "bB", "bN", "bR"],
            ["bp", "bp", "bp", "bp", "bp", "bp", "bp", "bp"],
            ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "],
            ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "],
            ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "],
            ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "],
            ["wp", "wp", "wp", "wp", "wp", "wp", "wp", "wp"],
            ["wR", "wN", "wB", "wQ", "wK", "wB", "wN", "wR"]
        ]
        self.selected_piece = None
        self.player_turn = "w"  # "w" for white, "b" for black

    def draw(self, screen):
        square_size = WIDTH // 8
        for row in range(8):
            for col in range(8):
                color = BLUE if (row + col) % 2 == 0 else WHITE  # Set color to blue for even squares, white for odd squares
                pygame.draw.rect(screen, color, (col * square_size, row * square_size, square_size, square_size))

        if self.selected_piece:
            row, col = self.selected_piece
            pygame.draw.rect(screen, GREEN , (col * square_size, row * square_size, square_size, square_size))  # Green color for selected piece square
            piece = self.board[row][col]
            if piece[0] == self.player_turn:  # Only show valid moves for the current player's pieces
                valid_moves = self.get_valid_moves(row, col)
                for move in valid_moves:
                    move_row, move_col = move
                    original_color = BLUE if (move_row + move_col) % 2 == 0 else WHITE
                    highlight_color = LIGHT_RED if original_color == WHITE else RED
                    pygame.draw.rect(screen, highlight_color, (move_col * square_size, move_row * square_size, square_size, square_size))

        for row in range(8):
            for col in range(8):
                piece = self.board[row][col]
                if piece != "  ":
                    piece_image = pygame.image.load(f"assets/{piece}.png")  # Load piece image
                    piece_image = pygame.transform.smoothscale(piece_image, (square_size, square_size))  # Smooth scaling
                    screen.blit(piece_image, (col * square_size, row * square_size))

    def select(self, row, col):
        piece = self.board[row][col]
        if self.selected_piece is None:
            if piece != "  " and piece[0] == self.player_turn:
                self.selected_piece = (row, col)
        else:
            if (row, col) in self.get_valid_moves(*self.selected_piece):
                self.move_piece(row, col)
            self.selected_piece = None

    def move_piece(self, row, col):
        start_row, start_col = self.selected_piece
        piece = self.board[start_row][start_col]

        if self.is_valid_move(piece, start_row, start_col, row, col):
            # Check for pawn promotion
            if piece[1] == "p" and (row == 0 or row == 7):
                promotion_piece = self.select_promotion_piece()
                self.board[row][col] = promotion_piece
            else:
                self.board[row][col] = piece
            self.board[start_row][start_col] = "  "
            self.player_turn = "b" if self.player_turn == "w" else "w"

    def is_valid_move(self, piece, start_row, start_col, end_row, end_col):
        # Check for valid move based on piece type
        piece_type = piece[1]
        if piece_type == "p":
            return self.valid_pawn_move(start_row, start_col, end_row, end_col, piece[0])
        elif piece_type == "R":
            return self.valid_rook_move(start_row, start_col, end_row, end_col)
        elif piece_type == "N":
            return self.valid_knight_move(start_row, start_col, end_row, end_col)
        elif piece_type == "B":
            return self.valid_bishop_move(start_row, start_col, end_row, end_col)
        elif piece_type == "Q":
            return self.valid_queen_move(start_row, start_col, end_row, end_col)
        elif piece_type == "K":
            return self.valid_king_move(start_row, start_col, end_row, end_col)

    def valid_pawn_move(self, start_row, start_col, end_row, end_col, color):
        # Movement for pawns
        if color == "w":
            if start_row == 6:  # First move for white pawns
                if end_col == start_col and (end_row == start_row - 1 or end_row == start_row - 2) and self.board[end_row][end_col] == "  ":
                    return True
                elif abs(end_col - start_col) == 1 and end_row == start_row - 1 and self.board[end_row][end_col][0] == "b":
                    return True
            else:
                if end_col == start_col and end_row == start_row - 1 and self.board[end_row][end_col] == "  ":
                    return True
                elif abs(end_col - start_col) == 1 and end_row == start_row - 1 and self.board[end_row][end_col][0] == "b":
                    return True
        else:
            if start_row == 1:  # First move for black pawns
                if end_col == start_col and (end_row == start_row + 1 or end_row == start_row + 2) and self.board[end_row][end_col] == "  ":
                    return True
                elif abs(end_col - start_col) == 1 and end_row == start_row + 1 and self.board[end_row][end_col][0] == "w":
                    return True
            else:
                if end_col == start_col and end_row == start_row + 1 and self.board[end_row][end_col] == "  ":
                    return True
                elif abs(end_col - start_col) == 1 and end_row == start_row + 1 and self.board[end_row][end_col][0] == "w":
                    return True
        return False
    def valid_rook_move(self, start_row, start_col, end_row, end_col):
        # Movement for rooks
        delta_row = end_row - start_row
        delta_col = end_col - start_col
        if delta_row == 0 and delta_col != 0:  # Moving horizontally
            direction = 1 if delta_col > 0 else -1
            for i in range(1, abs(delta_col)):
                if self.board[start_row][start_col + i * direction] != "  ":
                    return False
        elif delta_row != 0 and delta_col == 0:  # Moving vertically
            direction = 1 if delta_row > 0 else -1
            for i in range(1, abs(delta_row)):
                if self.board[start_row + i * direction][start_col] != "  ":
                    return False
        else:
            return False
        if self.board[end_row][end_col][0] == self.board[start_row][start_col][0]:
            return False
        return True

    def valid_knight_move(self, start_row, start_col, end_row, end_col):
        # Movement for knights
        delta_row = abs(end_row - start_row)
        delta_col = abs(end_col - start_col)
        if (delta_row == 2 and delta_col == 1) or (delta_row == 1 and delta_col == 2):
            if self.board[end_row][end_col][0] != self.board[start_row][start_col][0]:
                return True
        return False


    def valid_bishop_move(self, start_row, start_col, end_row, end_col):
        # Movement for bishops
        delta_row = end_row - start_row
        delta_col = end_col - start_col
        if abs(delta_row) != abs(delta_col):  # Must move diagonally
            return False
        direction_row = 1 if delta_row > 0 else -1
        direction_col = 1 if delta_col > 0 else -1
        for i in range(1, abs(delta_row)):
            if self.board[start_row + i * direction_row][start_col + i * direction_col] != "  ":
                return False
        if self.board[end_row][end_col][0] == self.board[start_row][start_col][0]:
            return False
        return True


    def valid_queen_move(self, start_row, start_col, end_row, end_col):
        # Movement for queens (combination of rook and bishop movements)
        return self.valid_rook_move(start_row, start_col, end_row, end_col) or self.valid_bishop_move(start_row, start_col, end_row, end_col)

    def valid_king_move(self, start_row, start_col, end_row, end_col):
        # Movement for kings
        delta_row = abs(end_row - start_row)
        delta_col = abs(end_col - start_col)
        if (delta_row == 1 and delta_col == 0) or (delta_row == 0 and delta_col == 1) or (delta_row == 1 and delta_col == 1):
            if self.board[end_row][end_col][0] != self.board[start_row][start_col][0]:
                return True
        return False

    def get_valid_moves(self, row, col):
        # Get valid moves for the selected piece
        piece = self.board[row][col]
        valid_moves = []
        king_color = self.player_turn
        if self.is_king_in_check(king_color):
            for i in range(8):
                for j in range(8):
                    if self.board[i][j][0] == king_color:
                        king_row, king_col = i, j
            if piece[0] == king_color:
                for i in range(8):
                    for j in range(8):
                        if self.is_valid_move(piece, row, col, i, j) and not self.move_will_cause_check(row, col, i, j):
                            valid_moves.append((i, j))
            else:
                for i in range(8):
                    for j in range(8):
                        if self.is_valid_move(piece, row, col, i, j) and not self.move_will_cause_check(king_row, king_col, i, j):
                            valid_moves.append((i, j))
            return valid_moves
        else:
            for i in range(8):
                for j in range(8):
                    if self.is_valid_move(piece, row, col, i, j):
                        valid_moves.append((i, j))
            return valid_moves


    def is_king_in_check(self, king_color):
        # Check if the king of the specified color is in check
        king_row, king_col = -1, -1
        for i in range(8):
            for j in range(8):
                if self.board[i][j] == f"{king_color}K":
                    king_row, king_col = i, j
                    break
        if king_row == -1 or king_col == -1:
            return False  # King not found
        opponent_color = "w" if king_color == "b" else "b"
        for i in range(8):
            for j in range(8):
                if self.board[i][j][0] == opponent_color:
                    if self.is_valid_move(self.board[i][j], i, j, king_row, king_col):
                        return True
        return False

    def is_checkmate(self, king_color):
        # Check if the game is in checkmate for the specified color
        for i in range(8):
            for j in range(8):
                if self.board[i][j][0] == king_color:
                    valid_moves = self.get_valid_moves(i, j)
                    for move in valid_moves:
                        if not self.move_will_cause_check(i, j, move[0], move[1]):
                            return False
        return True

    def move_will_cause_check(self, start_row, start_col, end_row, end_col):
        # Check if moving the piece from start to end will cause the king to be in check
        piece = self.board[start_row][start_col]
        temp_piece = self.board[end_row][end_col]
        self.board[end_row][end_col] = piece
        self.board[start_row][start_col] = "  "
        king_color = piece[0]
        result = self.is_king_in_check(king_color)
        self.board[start_row][start_col] = piece
        self.board[end_row][end_col] = temp_piece
        return result

    def is_stalemate(self, king_color):
        # Check if the game is in stalemate for the specified color
        for i in range(8):
            for j in range(8):
                if self.board[i][j][0] == king_color:
                    valid_moves = self.get_valid_moves(i, j)
                    if valid_moves:
                        return False
        return True

    def select_promotion_piece(self):
        pygame.display.set_caption("Pawn Promotion")
        font = pygame.font.Font(None, 36)
        screen_center = (WIDTH // 2, HEIGHT // 2)

        popup_surface = pygame.Surface((300, 200))
        popup_surface.fill(WHITE)

        text = font.render("Select Promotion Piece:", True, BLACK)
        text_rect = text.get_rect(center=(popup_surface.get_width() // 2, 40))
        popup_surface.blit(text, text_rect)

        options = []
        for i, piece in enumerate(PROMOTION_PIECES):
            option_text = font.render(piece, True, BLACK)
            option_rect = option_text.get_rect(center=(popup_surface.get_width() // 2, 80 + i * 40))
            options.append((option_text, option_rect))
            popup_surface.blit(option_text, option_rect)

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    for option_text, option_rect in options:
                        if option_rect.collidepoint(pygame.mouse.get_pos()):
                            promotion_piece = f"{self.player_turn[0]}{PROMOTION_PIECES[options.index((option_text, option_rect))][0]}"
                            return promotion_piece

            screen.fill((0, 0, 0, 100))
            screen.blit(popup_surface, (screen_center[0] - popup_surface.get_width() // 2, screen_center[1] - popup_surface.get_height() // 2))
            pygame.display.flip()

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Chess Game")
        clock = pygame.time.Clock()
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    col = pos[0] // (WIDTH // 8)
                    row = pos[1] // (HEIGHT // 8)
                    self.select(row, col)

            screen.fill(WHITE)
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = ChessGame()
    game.run()
