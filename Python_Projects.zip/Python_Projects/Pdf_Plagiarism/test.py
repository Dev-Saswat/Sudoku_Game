from pdf2image import convert_from_path
import os
import numpy as np
poppler_path = r'Release-24.02.0-0\poppler-24.02.0\Library\bin'

class pdf_image:

    
    def __init__(self):
        self.path = None
        self.name = None
        

    def load_file(self,pdf_location,image_store):
        self.path = image_store
        if os.path.isfile(f'{self.path}'):
            data = np.load(f'{self.path}')
            self.name = pdf_location
            images = convert_from_path(self.name, poppler_path=poppler_path)
            new_data = np.asarray(images)
            data = np.append(data , new_data)
            np.save(f'{self.path}',data)
        else:
            self.name = pdf_location
            images = convert_from_path(self.name, poppler_path=poppler_path)
            new_data = np.asarray(images)
            np.save(os.path.join(f'pdf_data\{self.path}'),new_data)
            
if __name__=='__main__':
    obj = pdf_image()
    obj.load_file('sample.pdf','test_arrays')
