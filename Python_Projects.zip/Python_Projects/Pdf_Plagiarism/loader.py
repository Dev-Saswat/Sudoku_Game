import numpy as np

# Load the data from the .npy file using a for loop
data = []
with open('my_image_arrays.npy', 'rb') as f:
    for line in f:
        data.append(line.strip())

for 
